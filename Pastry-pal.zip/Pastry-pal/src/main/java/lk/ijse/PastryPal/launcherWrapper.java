package lk.ijse.PastryPal;

public class launcherWrapper {
    public static void main(String[] args) {
        launcher.main(args);
    }
}
